--[[
  AnimationController  [MODULE SCRIPT]
  ===================
  State-driven animator: idle/walk/sprint/aim/attack/climb
]]

local AnimationController = {}


--- playAnim: Play a named animation track with priority and fade
function AnimationController.playAnim()
  -- TODO: implement
end


return AnimationController
