--[[
  MovementController  [MODULE SCRIPT]
  ==================
  Sprint, crouch, prone, vault, swim state machine
]]

local MovementController = {}



return MovementController
