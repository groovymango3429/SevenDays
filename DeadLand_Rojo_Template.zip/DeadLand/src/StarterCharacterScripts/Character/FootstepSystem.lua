--[[
  FootstepSystem  [MODULE SCRIPT]
  ==============
  Surface-dependent footstep sounds based on walk speed
]]

local FootstepSystem = {}



return FootstepSystem
