--[[
  InteractionRaycaster  [MODULE SCRIPT]
  ====================
  Front-facing ray: detect interactable blocks, entities, world items
]]

local InteractionRaycaster = {}



return InteractionRaycaster
