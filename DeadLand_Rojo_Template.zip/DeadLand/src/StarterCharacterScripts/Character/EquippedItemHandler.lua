--[[
  EquippedItemHandler  [MODULE SCRIPT]
  ===================
  Animate equipped weapon/tool, right-click ADS zoom
]]

local EquippedItemHandler = {}



return EquippedItemHandler
