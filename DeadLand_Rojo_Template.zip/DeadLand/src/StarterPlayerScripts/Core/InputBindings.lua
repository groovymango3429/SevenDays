--[[
  InputBindings  [MODULE SCRIPT]
  =============
  Action → key mappings with rebinding support
]]

local InputBindings = {}



return InputBindings
