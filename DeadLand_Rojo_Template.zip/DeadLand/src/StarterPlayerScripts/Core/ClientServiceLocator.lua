--[[
  ClientServiceLocator  [MODULE SCRIPT]
  ====================
  Client-side service registry (mirrors server ServiceLocator)
]]

local ClientServiceLocator = {}



return ClientServiceLocator
