--[[
  ReplicaClient  [MODULE SCRIPT]
  =============
  ReplicaService client listener — updates ClientState on change
]]

local ReplicaClient = {}


--- onChange: Subscribe to a specific replica key change
function ReplicaClient.onChange()
  -- TODO: implement
end


return ReplicaClient
