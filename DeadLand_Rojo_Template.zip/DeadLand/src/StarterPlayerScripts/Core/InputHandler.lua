--[[
  InputHandler  [MODULE SCRIPT]
  ============
  Unified input: keyboard/mouse, gamepad, touch abstraction
]]

local InputHandler = {}


--- bindAction: Register a callback for a named action
function InputHandler.bindAction()
  -- TODO: implement
end

--- unbindAction: Remove a callback for a named action
function InputHandler.unbindAction()
  -- TODO: implement
end


return InputHandler
