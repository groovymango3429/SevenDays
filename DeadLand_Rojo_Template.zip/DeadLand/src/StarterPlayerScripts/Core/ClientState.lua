--[[
  ClientState  [MODULE SCRIPT]
  ===========
  Read-only local mirror of the player's replicated profile data
]]

local ClientState = {}



return ClientState
