--[[
  NetworkClient  [MODULE SCRIPT]
  =============
  Listen to RemoteEvents, send to server, subscribe ByteNet packets
]]

local NetworkClient = {}


--- sendToServer: Fire a RemoteEvent or ByteNet packet to server
function NetworkClient.sendToServer()
  -- TODO: implement
end

--- onEvent: Register a handler for an incoming RemoteEvent
function NetworkClient.onEvent()
  -- TODO: implement
end


return NetworkClient
