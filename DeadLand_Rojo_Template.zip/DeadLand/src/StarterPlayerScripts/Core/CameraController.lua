--[[
  CameraController  [MODULE SCRIPT]
  ================
  FPS/TPS toggle, aim zoom, sway, RbxCameraShaker integration
]]

local CameraController = {}


--- setMode: Switch between FPS and TPS modes
function CameraController.setMode()
  -- TODO: implement
end

--- shakeCamera: Trigger a named RbxCameraShaker preset
function CameraController.shakeCamera()
  -- TODO: implement
end


return CameraController
