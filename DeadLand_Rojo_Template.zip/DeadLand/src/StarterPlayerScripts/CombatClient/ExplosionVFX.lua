--[[
  ExplosionVFX  [MODULE SCRIPT]
  ============
  Explosion particle systems, shockwave ring, screen flash
]]

local ExplosionVFX = {}



return ExplosionVFX
