--[[
  MeleeClient  [MODULE SCRIPT]
  ===========
  Swing animations, hit sparks, blood decal placement
]]

local MeleeClient = {}



return MeleeClient
