--[[
  WeaponClient  [MODULE SCRIPT]
  ============
  Client weapon model handling, muzzle flash, recoil animation
]]

local WeaponClient = {}



return WeaponClient
