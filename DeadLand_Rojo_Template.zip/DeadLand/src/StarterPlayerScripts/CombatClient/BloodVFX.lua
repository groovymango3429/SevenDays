--[[
  BloodVFX  [MODULE SCRIPT]
  ========
  Pooled blood decal parts, splatter particle bursts
]]

local BloodVFX = {}



return BloodVFX
