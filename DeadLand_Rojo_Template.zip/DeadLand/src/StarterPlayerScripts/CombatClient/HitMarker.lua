--[[
  HitMarker  [MODULE SCRIPT]
  =========
  Crosshair hitmarker: normal/crit/kill variants
]]

local HitMarker = {}



return HitMarker
