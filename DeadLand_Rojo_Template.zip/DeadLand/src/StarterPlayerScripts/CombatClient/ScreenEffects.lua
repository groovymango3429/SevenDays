--[[
  ScreenEffects  [MODULE SCRIPT]
  =============
  Vignette on low health, blood screen tint, intoxication blur
]]

local ScreenEffects = {}



return ScreenEffects
