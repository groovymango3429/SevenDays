--[[
  HitscanPredictor  [MODULE SCRIPT]
  ================
  Client-side FastCast prediction — reconciled with server result
]]

local HitscanPredictor = {}



return HitscanPredictor
