--[[
  AmbientSoundscape  [MODULE SCRIPT]
  =================
  Environmental: wind, crickets, rain, distant zombie groans
]]

local AmbientSoundscape = {}



return AmbientSoundscape
