--[[
  AudioOcclusion  [MODULE SCRIPT]
  ==============
  Raycast-based audio muffling when source is behind walls
]]

local AudioOcclusion = {}



return AudioOcclusion
