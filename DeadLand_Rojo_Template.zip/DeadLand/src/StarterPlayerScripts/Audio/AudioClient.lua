--[[
  AudioClient  [MODULE SCRIPT]
  ===========
  AudioPlayer integration: 3D sounds, spatial falloff, pooling
]]

local AudioClient = {}



return AudioClient
