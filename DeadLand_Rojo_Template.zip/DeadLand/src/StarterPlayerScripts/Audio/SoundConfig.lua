--[[
  SoundConfig  [MODULE SCRIPT]
  ===========
  Sound ID registry keyed by event name string
]]

local SoundConfig = {}



return SoundConfig
