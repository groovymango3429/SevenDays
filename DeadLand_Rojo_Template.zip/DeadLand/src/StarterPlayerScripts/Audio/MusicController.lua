--[[
  MusicController  [MODULE SCRIPT]
  ===============
  Biome music, horde night score, combat sting system
]]

local MusicController = {}


--- setTrack: Cross-fade to a new music track
function MusicController.setTrack()
  -- TODO: implement
end

--- playSting: Play a one-shot combat sting over current music
function MusicController.playSting()
  -- TODO: implement
end


return MusicController
