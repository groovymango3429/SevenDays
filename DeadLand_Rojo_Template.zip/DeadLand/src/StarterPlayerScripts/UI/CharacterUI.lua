--[[
  CharacterUI  [MODULE SCRIPT]
  ===========
  Skills and perks screen, attribute point allocation
]]

local CharacterUI = {}



return CharacterUI
