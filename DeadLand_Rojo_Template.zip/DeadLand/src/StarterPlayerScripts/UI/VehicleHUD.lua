--[[
  VehicleHUD  [MODULE SCRIPT]
  ==========
  Speedometer, fuel gauge, damage indicator
]]

local VehicleHUD = {}



return VehicleHUD
