--[[
  TraderUI  [MODULE SCRIPT]
  ========
  Shop buy/sell panels, currency display, trader reputation bar
]]

local TraderUI = {}



return TraderUI
