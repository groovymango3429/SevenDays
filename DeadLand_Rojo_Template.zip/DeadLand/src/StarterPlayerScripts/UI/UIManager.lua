--[[
  UIManager  [MODULE SCRIPT]
  =========
  Open/close/stack UI panels, input lock, escape key handling
]]

local UIManager = {}


--- open: Open a named UI panel
function UIManager.open()
  -- TODO: implement
end

--- close: Close a named UI panel
function UIManager.close()
  -- TODO: implement
end

--- isOpen: Check if panel is currently open
function UIManager.isOpen()
  -- TODO: implement
end


return UIManager
