--[[
  SettingsUI  [MODULE SCRIPT]
  ==========
  Graphics, audio, controls, accessibility settings panels
]]

local SettingsUI = {}



return SettingsUI
