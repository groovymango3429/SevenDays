--[[
  MinimapController  [MODULE SCRIPT]
  =================
  Real-time minimap: nearby entities, base outline, trader icons
]]

local MinimapController = {}



return MinimapController
