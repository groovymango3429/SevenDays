--[[
  HordeCountdownUI  [MODULE SCRIPT]
  ================
  Blood moon warning banner with day counter
]]

local HordeCountdownUI = {}



return HordeCountdownUI
