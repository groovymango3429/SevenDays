--[[
  ContainerUI  [MODULE SCRIPT]
  ===========
  Loot chest / storage UI with quick-transfer buttons
]]

local ContainerUI = {}



return ContainerUI
