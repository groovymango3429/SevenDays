--[[
  FarmingUI  [MODULE SCRIPT]
  =========
  Crop tooltip: growth %, water status, harvest prompt
]]

local FarmingUI = {}



return FarmingUI
