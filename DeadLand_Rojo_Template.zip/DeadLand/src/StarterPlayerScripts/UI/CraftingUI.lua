--[[
  CraftingUI  [MODULE SCRIPT]
  ==========
  Recipe list, ingredient highlight, craft queue progress bar
]]

local CraftingUI = {}



return CraftingUI
