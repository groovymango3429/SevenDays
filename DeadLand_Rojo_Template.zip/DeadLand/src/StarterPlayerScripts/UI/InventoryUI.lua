--[[
  InventoryUI  [MODULE SCRIPT]
  ===========
  Grid inventory, drag-and-drop, tooltip on hover, equipment slots
]]

local InventoryUI = {}



return InventoryUI
