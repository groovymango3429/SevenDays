--[[
  DamageNumbers  [MODULE SCRIPT]
  =============
  Floating damage text via UIEmitter, color-coded by damage type
]]

local DamageNumbers = {}



return DamageNumbers
