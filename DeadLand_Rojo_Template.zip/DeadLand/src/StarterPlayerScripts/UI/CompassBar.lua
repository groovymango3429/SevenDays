--[[
  CompassBar  [MODULE SCRIPT]
  ==========
  360 compass bar with cardinal labels and waypoint ticks
]]

local CompassBar = {}



return CompassBar
