--[[
  HUDController  [MODULE SCRIPT]
  =============
  Health/hunger/stamina bars, compass, time display, day counter
]]

local HUDController = {}



return HUDController
