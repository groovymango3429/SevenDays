--[[
  TooltipSystem  [MODULE SCRIPT]
  =============
  Hover tooltips for items, blocks, and entities
]]

local TooltipSystem = {}



return TooltipSystem
