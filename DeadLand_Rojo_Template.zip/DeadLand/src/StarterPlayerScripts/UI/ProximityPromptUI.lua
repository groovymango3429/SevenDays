--[[
  ProximityPromptUI  [MODULE SCRIPT]
  =================
  ProximityPromptCustomizer skins for interact/loot/mount
]]

local ProximityPromptUI = {}



return ProximityPromptUI
