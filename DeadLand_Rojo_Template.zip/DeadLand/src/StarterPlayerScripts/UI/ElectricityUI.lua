--[[
  ElectricityUI  [MODULE SCRIPT]
  =============
  Wire placement mode overlay, power grid status display
]]

local ElectricityUI = {}



return ElectricityUI
