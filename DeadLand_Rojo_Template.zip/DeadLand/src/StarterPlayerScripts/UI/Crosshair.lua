--[[
  Crosshair  [MODULE SCRIPT]
  =========
  Dynamic crosshair: spread bloom, hit flash, kill-confirm ring
]]

local Crosshair = {}



return Crosshair
