--[[
  NotificationSystem  [MODULE SCRIPT]
  ==================
  Toast notification queue, achievement popups, UIEmitter triggers
]]

local NotificationSystem = {}



return NotificationSystem
