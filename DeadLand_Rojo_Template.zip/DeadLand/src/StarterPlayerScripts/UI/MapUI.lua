--[[
  MapUI  [MODULE SCRIPT]
  =====
  Full world map, waypoint placement, POI icons, player pins
]]

local MapUI = {}



return MapUI
