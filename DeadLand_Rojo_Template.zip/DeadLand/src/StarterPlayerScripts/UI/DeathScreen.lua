--[[
  DeathScreen  [MODULE SCRIPT]
  ===========
  Respawn countdown, loot bag map waypoint, cause of death
]]

local DeathScreen = {}



return DeathScreen
