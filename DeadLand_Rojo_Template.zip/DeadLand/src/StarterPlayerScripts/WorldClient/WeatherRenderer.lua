--[[
  WeatherRenderer  [MODULE SCRIPT]
  ===============
  Rain particles, snow, fog density, lightning flash system
]]

local WeatherRenderer = {}



return WeatherRenderer
