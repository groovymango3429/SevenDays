--[[
  StructuralVFX  [MODULE SCRIPT]
  =============
  Collapse dust and rumble VFX on SI failure events
]]

local StructuralVFX = {}



return StructuralVFX
