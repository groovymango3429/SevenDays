--[[
  DayNightRenderer  [MODULE SCRIPT]
  ================
  Sky gradient, sun/moon arc, ambient light lerp over time
]]

local DayNightRenderer = {}



return DayNightRenderer
