--[[
  FarmingRenderer  [MODULE SCRIPT]
  ===============
  Crop growth stage visual updates
]]

local FarmingRenderer = {}



return FarmingRenderer
