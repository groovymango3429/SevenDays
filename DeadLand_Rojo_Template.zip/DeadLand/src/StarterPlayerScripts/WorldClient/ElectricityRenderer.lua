--[[
  ElectricityRenderer  [MODULE SCRIPT]
  ===================
  Wire glow, generator sparks, powered light flicker
]]

local ElectricityRenderer = {}



return ElectricityRenderer
