--[[
  QuestValidator  [MODULE SCRIPT]
  ==============
  Check completion conditions server-side
]]

local QuestValidator = {}


--- checkCompletion: Returns true if all objectives for a quest are met
function QuestValidator.checkCompletion()
  -- TODO: implement
end


return QuestValidator
