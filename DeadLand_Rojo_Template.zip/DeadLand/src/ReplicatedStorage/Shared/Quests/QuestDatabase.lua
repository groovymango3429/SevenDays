--[[
  QuestDatabase  [MODULE SCRIPT]
  =============
  All quests: objectives, rewards, prerequisites, chain IDs
]]

local QuestDatabase = {}



return QuestDatabase
