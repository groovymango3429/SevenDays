--[[
  QuestObjectiveTypes  [MODULE SCRIPT]
  ===================
  Kill, Fetch, Build, Explore, Craft, Survive objective definitions
]]

local QuestObjectiveTypes = {}



return QuestObjectiveTypes
