--[[
  SkillDefinitions  [MODULE SCRIPT]
  ================
  All skills: id, parent attribute, max level, per-level effects
]]

local SkillDefinitions = {}



return SkillDefinitions
