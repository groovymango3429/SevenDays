--[[
  HungerThirstSystem  [MODULE SCRIPT]
  ==================
  Decay rates, starvation/dehydration damage threshold formulas
]]

local HungerThirstSystem = {}



return HungerThirstSystem
