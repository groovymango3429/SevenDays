--[[
  TemperatureSystem  [MODULE SCRIPT]
  =================
  Heat/cold from weather + armor insulation + proximity to fire
]]

local TemperatureSystem = {}



return TemperatureSystem
