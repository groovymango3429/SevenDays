--[[
  PlayerStatsSchema  [MODULE SCRIPT]
  =================
  Default stats template for fresh characters
]]

local PlayerStatsSchema = {}



return PlayerStatsSchema
