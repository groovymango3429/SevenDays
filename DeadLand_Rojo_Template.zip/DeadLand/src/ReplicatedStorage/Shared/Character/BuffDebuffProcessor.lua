--[[
  BuffDebuffProcessor  [MODULE SCRIPT]
  ===================
  Apply, expire, stack, and merge status effects
]]

local BuffDebuffProcessor = {}


--- apply: Add a buff/debuff to character state
function BuffDebuffProcessor.apply()
  -- TODO: implement
end

--- tick: Process per-second buff ticks
function BuffDebuffProcessor.tick()
  -- TODO: implement
end

--- expire: Remove expired effects and revert changes
function BuffDebuffProcessor.expire()
  -- TODO: implement
end


return BuffDebuffProcessor
