--[[
  SkillProgressionCalc  [MODULE SCRIPT]
  ====================
  XP curves, level thresholds, attribute point costs
]]

local SkillProgressionCalc = {}


--- xpForLevel: Returns XP required for given level
function SkillProgressionCalc.xpForLevel()
  -- TODO: implement
end

--- applyLevelUp: Apply stat changes for a skill level
function SkillProgressionCalc.applyLevelUp()
  -- TODO: implement
end


return SkillProgressionCalc
