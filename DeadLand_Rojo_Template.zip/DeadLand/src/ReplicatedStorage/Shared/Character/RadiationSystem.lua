--[[
  RadiationSystem  [MODULE SCRIPT]
  ===============
  Rad zone exposure accumulation, sickness stages, anti-rad meds
]]

local RadiationSystem = {}



return RadiationSystem
