--[[
  StaminaSystem  [MODULE SCRIPT]
  =============
  Regen/drain curves, sprint cost, attack cost per weapon class
]]

local StaminaSystem = {}



return StaminaSystem
