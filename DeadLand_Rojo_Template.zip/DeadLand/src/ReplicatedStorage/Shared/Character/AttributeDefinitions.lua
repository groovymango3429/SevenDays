--[[
  AttributeDefinitions  [MODULE SCRIPT]
  ====================
  Strength, Fortitude, Agility, Intellect, Perception — scaling formulas
]]

local AttributeDefinitions = {}



return AttributeDefinitions
