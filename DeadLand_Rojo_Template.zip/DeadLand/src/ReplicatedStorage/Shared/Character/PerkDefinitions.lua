--[[
  PerkDefinitions  [MODULE SCRIPT]
  ===============
  All perks: prerequisites, rank count, effect per rank, icon
]]

local PerkDefinitions = {}



return PerkDefinitions
