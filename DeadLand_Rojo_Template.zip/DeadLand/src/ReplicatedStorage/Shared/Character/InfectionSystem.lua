--[[
  InfectionSystem  [MODULE SCRIPT]
  ===============
  Zombie bite infection stages, progression speed, cure item check
]]

local InfectionSystem = {}



return InfectionSystem
