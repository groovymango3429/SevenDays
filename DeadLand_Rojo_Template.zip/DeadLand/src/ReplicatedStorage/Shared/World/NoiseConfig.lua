--[[
  NoiseConfig  [MODULE SCRIPT]
  ===========
  Octave noise parameters for terrain, caves, ore veins
]]

local NoiseConfig = {}



return NoiseConfig
