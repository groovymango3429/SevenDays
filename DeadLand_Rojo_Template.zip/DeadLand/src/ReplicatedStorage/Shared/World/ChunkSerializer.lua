--[[
  ChunkSerializer  [MODULE SCRIPT]
  ===============
  Pack/unpack chunk to binary string for network and DataStore
]]

local ChunkSerializer = {}


--- serialize: Convert chunk array to compact binary string
function ChunkSerializer.serialize()
  -- TODO: implement
end

--- deserialize: Convert binary string back to chunk array
function ChunkSerializer.deserialize()
  -- TODO: implement
end


return ChunkSerializer
