--[[
  ChunkData  [MODULE SCRIPT]
  =========
  Chunk data structure — 32³ flat array + biome/light metadata
]]

local ChunkData = {}


--- new: Create empty chunk data for given coordinate
function ChunkData.new()
  -- TODO: implement
end

--- getBlock: Get block at local x,y,z
function ChunkData.getBlock()
  -- TODO: implement
end

--- setBlock: Set block at local x,y,z
function ChunkData.setBlock()
  -- TODO: implement
end


return ChunkData
