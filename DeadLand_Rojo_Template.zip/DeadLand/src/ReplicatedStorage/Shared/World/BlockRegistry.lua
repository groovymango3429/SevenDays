--[[
  BlockRegistry  [MODULE SCRIPT]
  =============
  All block type definitions: id, name, hardness, material, harvest loot
]]

local BlockRegistry = {}


--- getBlock: Get block definition by id
function BlockRegistry.getBlock()
  -- TODO: implement
end

--- getAllBlocks: Return all block definitions
function BlockRegistry.getAllBlocks()
  -- TODO: implement
end


return BlockRegistry
