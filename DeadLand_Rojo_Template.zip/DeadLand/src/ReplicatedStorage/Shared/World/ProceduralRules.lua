--[[
  ProceduralRules  [MODULE SCRIPT]
  ===============
  Structure generation rules: cities, POIs, roads, forests
]]

local ProceduralRules = {}



return ProceduralRules
