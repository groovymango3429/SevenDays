--[[
  WorldConstants  [MODULE SCRIPT]
  ==============
  World size limits, sea level, max build height, safe spawn region
]]

local WorldConstants = {}



return WorldConstants
