--[[
  ChunkConstants  [MODULE SCRIPT]
  ==============
  CHUNK_SIZE=32, RENDER_DISTANCE, LOD tier thresholds
]]

local ChunkConstants = {}



return ChunkConstants
