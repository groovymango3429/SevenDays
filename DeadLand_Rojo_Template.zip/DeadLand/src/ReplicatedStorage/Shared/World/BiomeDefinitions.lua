--[[
  BiomeDefinitions  [MODULE SCRIPT]
  ================
  Biome configs: block palettes, spawn tables, music track ids
]]

local BiomeDefinitions = {}



return BiomeDefinitions
