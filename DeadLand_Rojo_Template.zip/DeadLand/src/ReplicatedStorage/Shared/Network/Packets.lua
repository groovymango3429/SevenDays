--[[
  Packets  [MODULE SCRIPT]
  =======
  ByteNet packet schemas: PlayerPosition, EntityPosition, BulletRay, VehicleState
]]

local Packets = {}



return Packets
