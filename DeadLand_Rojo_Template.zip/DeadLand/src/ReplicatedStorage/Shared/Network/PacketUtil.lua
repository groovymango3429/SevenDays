--[[
  PacketUtil  [MODULE SCRIPT]
  ==========
  Serialize/deserialize helpers, delta compression utilities
]]

local PacketUtil = {}



return PacketUtil
