--[[
  LootTableDatabase  [MODULE SCRIPT]
  =================
  Named loot tables: weighted item pools, min/max quantity
]]

local LootTableDatabase = {}



return LootTableDatabase
