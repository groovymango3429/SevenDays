--[[
  ContainerDefinitions  [MODULE SCRIPT]
  ====================
  Container type → loot table name mapping
]]

local ContainerDefinitions = {}



return ContainerDefinitions
