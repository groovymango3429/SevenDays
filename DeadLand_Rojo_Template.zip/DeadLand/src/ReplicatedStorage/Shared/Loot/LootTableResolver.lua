--[[
  LootTableResolver  [MODULE SCRIPT]
  =================
  Roll loot tables respecting GameStage and player luck stat
]]

local LootTableResolver = {}


--- roll: Given tableName + gameStage → returns array of {itemId, qty}
function LootTableResolver.roll()
  -- TODO: implement
end


return LootTableResolver
