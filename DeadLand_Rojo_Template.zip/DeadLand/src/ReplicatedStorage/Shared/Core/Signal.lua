--[[
  Signal  [MODULE SCRIPT]
  ======
  Re-export of Packages/MadworkSignal. Use this, never require Packages directly.
See architecture doc §0 for re-export explanation.
]]

local Signal = {}


--- new: Create a new Signal instance
function Signal.new()
  -- TODO: implement
end

--- Connect: Subscribe to signal
function Signal.Connect()
  -- TODO: implement
end

--- Fire: Broadcast to all listeners
function Signal.Fire()
  -- TODO: implement
end

--- Destroy: Clean up signal and connections
function Signal.Destroy()
  -- TODO: implement
end


return Signal
