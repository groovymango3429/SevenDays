--[[
  NetworkBridge  [MODULE SCRIPT]
  =============
  Abstraction over ByteNet + RemoteEvents
]]

local NetworkBridge = {}


--- send: Send data to server (client) or client (server)
function NetworkBridge.send()
  -- TODO: implement
end

--- receive: Register handler for incoming messages
function NetworkBridge.receive()
  -- TODO: implement
end


return NetworkBridge
