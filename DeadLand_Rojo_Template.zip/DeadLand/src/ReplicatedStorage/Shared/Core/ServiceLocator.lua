--[[
  ServiceLocator  [MODULE SCRIPT]
  ==============
  Central service registry — register and retrieve any manager
]]

local ServiceLocator = {}


--- register: Register a service by name
function ServiceLocator.register()
  -- TODO: implement
end

--- get: Retrieve a service by name
function ServiceLocator.get()
  -- TODO: implement
end


return ServiceLocator
