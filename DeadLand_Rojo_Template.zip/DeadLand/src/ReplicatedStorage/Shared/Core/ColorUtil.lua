--[[
  ColorUtil  [MODULE SCRIPT]
  =========
  Lerp colors, health-to-color gradients, damage type colors
]]

local ColorUtil = {}



return ColorUtil
