--[[
  SchedulerUtil  [MODULE SCRIPT]
  =============
  Deferred task scheduler, heartbeat hooks, throttle/debounce helpers
]]

local SchedulerUtil = {}


--- defer: Schedule a function on next heartbeat
function SchedulerUtil.defer()
  -- TODO: implement
end

--- throttle: Wrap fn to run at most once per interval
function SchedulerUtil.throttle()
  -- TODO: implement
end


return SchedulerUtil
