--[[
  VectorUtil  [MODULE SCRIPT]
  ==========
  Grid alignment, chunk coordinate conversion, octree helpers
]]

local VectorUtil = {}


--- worldToChunk: Convert world Vector3 to chunk coordinate
function VectorUtil.worldToChunk()
  -- TODO: implement
end

--- chunkToWorld: Convert chunk coord to world origin
function VectorUtil.chunkToWorld()
  -- TODO: implement
end


return VectorUtil
