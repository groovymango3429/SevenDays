--[[
  Logger  [MODULE SCRIPT]
  ======
  Structured logging: DEBUG/INFO/WARN/ERROR with timestamps
]]

local Logger = {}


--- log: Log at given level (level, message)
function Logger.log()
  -- TODO: implement
end

--- warn: Log a warning
function Logger.warn()
  -- TODO: implement
end

--- error: Log error, optionally throw
function Logger.error()
  -- TODO: implement
end


return Logger
