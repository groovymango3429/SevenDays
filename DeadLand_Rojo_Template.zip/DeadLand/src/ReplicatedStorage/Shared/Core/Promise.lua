--[[
  Promise  [MODULE SCRIPT]
  =======
  Re-export of Packages/Promise. Lua async/promise pattern.
See architecture doc §0 for re-export explanation.
]]

local Promise = {}


--- new: Create async Promise(resolve, reject)
function Promise.new()
  -- TODO: implement
end

--- resolve: Resolve with value
function Promise.resolve()
  -- TODO: implement
end

--- reject: Reject with error
function Promise.reject()
  -- TODO: implement
end


return Promise
