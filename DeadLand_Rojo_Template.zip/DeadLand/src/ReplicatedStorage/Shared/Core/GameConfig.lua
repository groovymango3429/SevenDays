--[[
  GameConfig  [MODULE SCRIPT]
  ==========
  Global constants: version, tick rate, world seed, max players
]]

local GameConfig = {}


--- get: Return the full config table
function GameConfig.get()
  -- TODO: implement
end


return GameConfig
