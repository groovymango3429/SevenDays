--[[
  MathUtil  [MODULE SCRIPT]
  ========
  Lerp, noise, seed hashing, grid snapping, sphere sampling
]]

local MathUtil = {}



return MathUtil
