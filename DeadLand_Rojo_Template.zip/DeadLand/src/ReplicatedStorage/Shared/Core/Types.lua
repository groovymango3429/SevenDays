--[[
  Types  [MODULE SCRIPT]
  =====
  Luau strict-mode type definitions shared across all scripts
]]

local Types = {}



return Types
