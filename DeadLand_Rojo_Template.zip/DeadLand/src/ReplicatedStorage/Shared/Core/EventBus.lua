--[[
  EventBus  [MODULE SCRIPT]
  ========
  Project-wide publish/subscribe using MadworkSignal
]]

local EventBus = {}


--- subscribe: Listen for a named event
function EventBus.subscribe()
  -- TODO: implement
end

--- publish: Fire a named event to all subscribers
function EventBus.publish()
  -- TODO: implement
end


return EventBus
