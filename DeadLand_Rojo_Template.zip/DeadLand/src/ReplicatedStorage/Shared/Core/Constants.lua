--[[
  Constants  [MODULE SCRIPT]
  =========
  Enums: ItemType, DamageType, ZombieState, BiomeType, WeatherType, QuestState
]]

local Constants = {}



return Constants
