--[[
  QualityTiers  [MODULE SCRIPT]
  ============
  Tier 1-6 stat multipliers, color codes, craft unlock levels
]]

local QualityTiers = {}



return QualityTiers
