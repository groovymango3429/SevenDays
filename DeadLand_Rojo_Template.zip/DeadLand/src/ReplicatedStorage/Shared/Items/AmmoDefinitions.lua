--[[
  AmmoDefinitions  [MODULE SCRIPT]
  ===============
  Ammo types: caliber, damage multiplier, penetration, tracer flag
]]

local AmmoDefinitions = {}



return AmmoDefinitions
