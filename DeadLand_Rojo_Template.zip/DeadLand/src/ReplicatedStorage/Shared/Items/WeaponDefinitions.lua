--[[
  WeaponDefinitions  [MODULE SCRIPT]
  =================
  All weapons: damage, range, ROF, ammo type, recoil, attachment slots
]]

local WeaponDefinitions = {}



return WeaponDefinitions
