--[[
  ItemCategories  [MODULE SCRIPT]
  ==============
  Category tree: Weapon/Melee/Blunt, Food/Drink/Medkit, Tool, etc.
]]

local ItemCategories = {}



return ItemCategories
