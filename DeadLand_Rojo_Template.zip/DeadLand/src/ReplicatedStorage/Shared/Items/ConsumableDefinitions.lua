--[[
  ConsumableDefinitions  [MODULE SCRIPT]
  =====================
  Food/drink/meds: nutrition values, applied status effects, timers
]]

local ConsumableDefinitions = {}



return ConsumableDefinitions
