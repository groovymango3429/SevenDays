--[[
  ToolDefinitions  [MODULE SCRIPT]
  ===============
  Tools: harvest speed, target block tags, skill requirement
]]

local ToolDefinitions = {}



return ToolDefinitions
