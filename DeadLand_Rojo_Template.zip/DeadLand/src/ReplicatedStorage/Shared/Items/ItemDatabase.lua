--[[
  ItemDatabase  [MODULE SCRIPT]
  ============
  Master registry of 500+ items — all fields, all categories
]]

local ItemDatabase = {}



return ItemDatabase
