--[[
  ElectricComponentDefs  [MODULE SCRIPT]
  =====================
  Generator, battery, wire, switch, solar, turret, light definitions
]]

local ElectricComponentDefs = {}



return ElectricComponentDefs
