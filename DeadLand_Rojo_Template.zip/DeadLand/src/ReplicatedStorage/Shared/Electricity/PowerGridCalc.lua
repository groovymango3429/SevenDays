--[[
  PowerGridCalc  [MODULE SCRIPT]
  =============
  Circuit BFS traversal, demand vs supply, overload detection
]]

local PowerGridCalc = {}


--- traverse: BFS from generator to find all connected components
function PowerGridCalc.traverse()
  -- TODO: implement
end

--- isOverloaded: Returns true if demand exceeds supply
function PowerGridCalc.isOverloaded()
  -- TODO: implement
end


return PowerGridCalc
