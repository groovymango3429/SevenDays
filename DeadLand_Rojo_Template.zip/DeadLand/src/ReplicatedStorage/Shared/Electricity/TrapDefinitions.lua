--[[
  TrapDefinitions  [MODULE SCRIPT]
  ===============
  Electric fence, dart trap, blade trap config tables
]]

local TrapDefinitions = {}



return TrapDefinitions
