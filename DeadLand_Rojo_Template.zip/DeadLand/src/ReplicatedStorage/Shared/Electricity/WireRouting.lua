--[[
  WireRouting  [MODULE SCRIPT]
  ===========
  Grid-snapped wire placement, max length, node graph construction
]]

local WireRouting = {}



return WireRouting
