--[[
  CraftingValidator  [MODULE SCRIPT]
  =================
  Validate crafts: has ingredients, station present, skill met
]]

local CraftingValidator = {}


--- canCraft: Returns {success=bool, reason=string}
function CraftingValidator.canCraft()
  -- TODO: implement
end


return CraftingValidator
