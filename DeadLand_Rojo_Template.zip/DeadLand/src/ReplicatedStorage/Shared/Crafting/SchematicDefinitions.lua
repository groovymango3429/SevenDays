--[[
  SchematicDefinitions  [MODULE SCRIPT]
  ====================
  Learnable recipes unlocked via in-world schematic items
]]

local SchematicDefinitions = {}



return SchematicDefinitions
