--[[
  CraftingStations  [MODULE SCRIPT]
  ================
  Station definitions: workbench, forge, chemistry, campfire
]]

local CraftingStations = {}



return CraftingStations
