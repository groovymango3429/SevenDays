--[[
  RecipeDatabase  [MODULE SCRIPT]
  ==============
  All crafting recipes: input items, output, required station, craft time
]]

local RecipeDatabase = {}



return RecipeDatabase
