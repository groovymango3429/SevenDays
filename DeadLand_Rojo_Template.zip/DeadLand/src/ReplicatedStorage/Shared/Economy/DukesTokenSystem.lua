--[[
  DukesTokenSystem  [MODULE SCRIPT]
  ================
  Currency maths: buy/sell pricing, reputation modifier formulas
]]

local DukesTokenSystem = {}



return DukesTokenSystem
