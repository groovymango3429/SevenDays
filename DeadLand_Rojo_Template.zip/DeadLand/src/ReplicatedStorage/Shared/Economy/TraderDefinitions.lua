--[[
  TraderDefinitions  [MODULE SCRIPT]
  =================
  Trader NPC configs: inventory pools, refresh intervals, tier
]]

local TraderDefinitions = {}



return TraderDefinitions
