--[[
  BarterRules  [MODULE SCRIPT]
  ===========
  Non-currency trade equivalencies
]]

local BarterRules = {}



return BarterRules
