--[[
  PlantRegistry  [MODULE SCRIPT]
  =============
  Wild harvestable plants: spawn rates, biome affinity
]]

local PlantRegistry = {}



return PlantRegistry
