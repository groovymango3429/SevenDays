--[[
  FarmingDefinitions  [MODULE SCRIPT]
  ==================
  Crops: growth stages, time per stage, water need, yield, soil type
]]

local FarmingDefinitions = {}



return FarmingDefinitions
