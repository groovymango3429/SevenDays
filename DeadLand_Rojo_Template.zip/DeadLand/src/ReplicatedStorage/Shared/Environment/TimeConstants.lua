--[[
  TimeConstants  [MODULE SCRIPT]
  =============
  Day length in seconds, horde night threshold, noon/midnight offsets
]]

local TimeConstants = {}



return TimeConstants
