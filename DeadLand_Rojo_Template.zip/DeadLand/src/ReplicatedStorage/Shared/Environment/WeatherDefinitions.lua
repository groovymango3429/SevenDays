--[[
  WeatherDefinitions  [MODULE SCRIPT]
  ==================
  Weather types: clear/rain/fog/storm/blizzard — transition rules
]]

local WeatherDefinitions = {}



return WeatherDefinitions
