--[[
  VehiclePhysicsConfig  [MODULE SCRIPT]
  ====================
  Suspension, torque curves, brake force, turning radius per vehicle
]]

local VehiclePhysicsConfig = {}



return VehiclePhysicsConfig
