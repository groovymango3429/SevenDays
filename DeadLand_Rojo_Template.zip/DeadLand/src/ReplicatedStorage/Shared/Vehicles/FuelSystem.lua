--[[
  FuelSystem  [MODULE SCRIPT]
  ==========
  Fuel types, consumption rates per speed, reserve calculations
]]

local FuelSystem = {}



return FuelSystem
