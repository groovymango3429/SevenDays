--[[
  VehicleDefinitions  [MODULE SCRIPT]
  ==================
  All vehicles: stats, seat count, fuel type, trunk size, model id
]]

local VehicleDefinitions = {}



return VehicleDefinitions
