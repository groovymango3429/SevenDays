--[[
  EntityDefinitions  [MODULE SCRIPT]
  =================
  All entity type configs: id, base stats, model id, loot table, AI profile
]]

local EntityDefinitions = {}



return EntityDefinitions
