--[[
  DamageCalc  [MODULE SCRIPT]
  ==========
  Full damage pipeline: raw → type modifier → armor reduction → resistance → final
]]

local DamageCalc = {}


--- calculate: Given attacker + defender stats, returns final damage value and type
function DamageCalc.calculate()
  -- TODO: implement
end


return DamageCalc
