--[[
  CombatConstants  [MODULE SCRIPT]
  ===============
  Max engagement range, melee reach, knockback coefficients
]]

local CombatConstants = {}



return CombatConstants
