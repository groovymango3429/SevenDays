--[[
  ArmorDefinitions  [MODULE SCRIPT]
  ================
  All armor sets: slots, defense ratings, durability, stat modifiers
]]

local ArmorDefinitions = {}



return ArmorDefinitions
