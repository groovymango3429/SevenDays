--[[
  HealthComponent  [MODULE SCRIPT]
  ===============
  Shared health maths: overkill, healing clamp, shield layering
]]

local HealthComponent = {}



return HealthComponent
