--[[
  EntityUtil  [MODULE SCRIPT]
  ==========
  Tag helpers, model binding, hitbox region definitions
]]

local EntityUtil = {}



return EntityUtil
