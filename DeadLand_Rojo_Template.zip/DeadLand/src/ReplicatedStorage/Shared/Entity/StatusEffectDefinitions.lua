--[[
  StatusEffectDefinitions  [MODULE SCRIPT]
  =======================
  All buffs/debuffs: duration, tick effect, max stacks, icon, sound id
]]

local StatusEffectDefinitions = {}



return StatusEffectDefinitions
