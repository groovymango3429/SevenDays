--[[
  HitboxConfig  [MODULE SCRIPT]
  ============
  Per-entity hitbox regions and damage multipliers (head=2x, legs=0.7x)
]]

local HitboxConfig = {}



return HitboxConfig
