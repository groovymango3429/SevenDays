# Packages

Install these packages using [Wally](https://github.com/UpliftGames/wally) or download manually.

Add each package as a ModuleScript child of this Packages folder.

## Required Packages

| Package | Source | Purpose |
|---------|--------|---------|
| ProfileStore | [GitHub](https://github.com/MadStudioRoblox/ProfileStore) | Player data persistence |
| ReplicaService | [GitHub](https://github.com/MadStudioRoblox/ReplicaService) | Server→Client data replication |
| ByteNet | [GitHub](https://github.com/ffrostfall/ByteNet) | High-volume binary networking |
| Cmdr | [GitHub](https://github.com/evaera/Cmdr) | Admin command framework |
| ZonePlus | [GitHub](https://github.com/1ForeverHD/ZonePlus) | Region/zone detection |
| RbxCameraShaker | [GitHub](https://github.com/Sleitnick/RbxCameraShaker) | Camera trauma effects |
| MadworkSignal | [GitHub](https://github.com/MadStudioRoblox/Madwork-Signal) | Fast signal class |
| MadworkMaid | [GitHub](https://github.com/MadStudioRoblox/Madwork-Maid) | Resource cleanup |
| AudioPlayer | [DevForum](https://devforum.roblox.com) | Pooled 3D audio |
| SuphiDatastore | [GitHub](https://github.com/Suphi) | Fallback persistence |
| UIEmitter | [DevForum](https://devforum.roblox.com) | UI particle effects |
| ProximityPromptCustomizer | [DevForum](https://devforum.roblox.com) | Custom prompt UI |
| FastCast | [GitHub](https://github.com/EtiTheSpirit/RaycastHitboxV4) | Projectile simulation |
| TableUtil | [GitHub](https://github.com/Sleitnick/RbxUtil) | Table utilities |
| Promise | [GitHub](https://github.com/evaera/roblox-lua-promise) | Async promises |

## Using Wally (Recommended)
See `wally.toml` in the project root.
