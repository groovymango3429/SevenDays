--[[
  LootDropService  [MODULE SCRIPT]
  ===============
  Entity death → roll loot table → spawn WorldItem in world
]]

local LootDropService = {}



return LootDropService
