--[[
  ProjectileService  [MODULE SCRIPT]
  =================
  Server FastCast simulation for grenades and arc projectiles
]]

local ProjectileService = {}



return ProjectileService
