--[[
  ArmorDurabilityService  [MODULE SCRIPT]
  ======================
  Reduce armor durability per hit, break at 0
]]

local ArmorDurabilityService = {}



return ArmorDurabilityService
