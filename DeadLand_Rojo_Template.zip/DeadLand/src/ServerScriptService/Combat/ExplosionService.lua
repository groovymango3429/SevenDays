--[[
  ExplosionService  [MODULE SCRIPT]
  ================
  Sphere damage query, block damage, debris spawning
]]

local ExplosionService = {}


--- detonate: Process explosion at position with radius — damages entities + blocks
function ExplosionService.detonate()
  -- TODO: implement
end


return ExplosionService
