--[[
  HitscanValidator  [MODULE SCRIPT]
  ================
  Server re-ray validation with lag compensation buffer
]]

local HitscanValidator = {}



return HitscanValidator
