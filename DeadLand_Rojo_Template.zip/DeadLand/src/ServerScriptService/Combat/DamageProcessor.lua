--[[
  DamageProcessor  [MODULE SCRIPT]
  ===============
  Apply DamageCalc result: deduct HP, apply status, award XP
]]

local DamageProcessor = {}



return DamageProcessor
