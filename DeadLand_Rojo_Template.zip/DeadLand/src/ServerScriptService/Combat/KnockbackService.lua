--[[
  KnockbackService  [MODULE SCRIPT]
  ================
  Apply VectorForce impulse on confirmed hit
]]

local KnockbackService = {}



return KnockbackService
