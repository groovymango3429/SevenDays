--[[
  MeleeHitValidator  [MODULE SCRIPT]
  =================
  Distance + timing window validation for melee hits
]]

local MeleeHitValidator = {}



return MeleeHitValidator
