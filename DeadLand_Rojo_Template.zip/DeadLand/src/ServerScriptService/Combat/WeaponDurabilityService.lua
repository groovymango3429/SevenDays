--[[
  WeaponDurabilityService  [MODULE SCRIPT]
  =======================
  Weapon wear on attack, repair cost calculation
]]

local WeaponDurabilityService = {}



return WeaponDurabilityService
