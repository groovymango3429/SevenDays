--[[
  ModLoader  [MODULE SCRIPT]
  =========
  Discover, validate, sort by load_order, and merge all mods at boot
]]

local ModLoader = {}


--- loadAll: Scan Mods folder and process each valid mod package
function ModLoader.loadAll()
  -- TODO: implement
end

--- mergeDatabase: Deep merge mod data table into master database
function ModLoader.mergeDatabase()
  -- TODO: implement
end


return ModLoader
