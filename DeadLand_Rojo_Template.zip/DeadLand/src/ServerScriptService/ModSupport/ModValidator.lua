--[[
  ModValidator  [MODULE SCRIPT]
  ============
  Schema validation for mod data — rejects malformed mods with error log
]]

local ModValidator = {}



return ModValidator
