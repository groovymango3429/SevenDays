--[[
  ModRegistry  [MODULE SCRIPT]
  ===========
  Loaded mod manifest registry for runtime queries
]]

local ModRegistry = {}



return ModRegistry
