--[[
  AIDirector  [MODULE SCRIPT]
  ==========
  AI budget controller — scales tick rate, enforces entity count limits
]]

local AIDirector = {}



return AIDirector
