--[[
  ZombieController  [MODULE SCRIPT]
  ================
  Per-zombie update: sense → decide → move → animate
]]

local ZombieController = {}



return ZombieController
