--[[
  BossController  [MODULE SCRIPT]
  ==============
  Boss multi-phase AI with special ability triggers
]]

local BossController = {}



return BossController
