--[[
  SpawnService  [MODULE SCRIPT]
  ============
  Ambient spawner: POI/wilderness/night escalation checks
]]

local SpawnService = {}



return SpawnService
