--[[
  AnimalController  [MODULE SCRIPT]
  ================
  Passive/aggressive animal AI: flee, graze, attack states
]]

local AnimalController = {}



return AnimalController
