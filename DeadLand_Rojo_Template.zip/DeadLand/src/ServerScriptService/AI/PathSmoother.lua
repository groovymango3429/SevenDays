--[[
  PathSmoother  [MODULE SCRIPT]
  ============
  Funnel algorithm + corner cutting for fluid movement
]]

local PathSmoother = {}



return PathSmoother
