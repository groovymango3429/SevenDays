--[[
  ZombieStateMachine  [MODULE SCRIPT]
  ==================
  States: IDLE/PATROL/ALERT/CHASE/ATTACK/RAGDOLL/DEAD
]]

local ZombieStateMachine = {}


--- transition: Move zombie between states with entry/exit callbacks
function ZombieStateMachine.transition()
  -- TODO: implement
end

--- tick: Run current state logic for this frame
function ZombieStateMachine.tick()
  -- TODO: implement
end


return ZombieStateMachine
