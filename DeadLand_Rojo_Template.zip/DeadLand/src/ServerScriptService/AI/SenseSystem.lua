--[[
  SenseSystem  [MODULE SCRIPT]
  ===========
  Sight cone + hearing radius + smell detection per zombie
]]

local SenseSystem = {}



return SenseSystem
