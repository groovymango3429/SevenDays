--[[
  ObstacleBreaker  [MODULE SCRIPT]
  ===============
  Zombie block-breaking: select weakest adjacent block, apply dig damage
]]

local ObstacleBreaker = {}



return ObstacleBreaker
