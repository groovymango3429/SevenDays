--[[
  SpawnPool  [MODULE SCRIPT]
  =========
  Object pool for zombie character models — reduces GC pressure
]]

local SpawnPool = {}



return SpawnPool
