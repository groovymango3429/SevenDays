--[[
  SpawnBudget  [MODULE SCRIPT]
  ===========
  Per-player and global zombie count caps with priority queue
]]

local SpawnBudget = {}



return SpawnBudget
