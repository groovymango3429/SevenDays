--[[
  ElectricityManager  [MODULE SCRIPT]
  ==================
  Power grid graph ticks, component activation, surge handling
]]

local ElectricityManager = {}



return ElectricityManager
