--[[
  EntityManager  [MODULE SCRIPT]
  =============
  Entity registry, spawn/despawn, per-tick update dispatch
]]

local EntityManager = {}


--- spawnEntity: Instantiate entity from definition, register in world
function EntityManager.spawnEntity()
  -- TODO: implement
end

--- despawnEntity: Remove entity, drop loot, clean up
function EntityManager.despawnEntity()
  -- TODO: implement
end

--- getEntity: Look up entity by id
function EntityManager.getEntity()
  -- TODO: implement
end


return EntityManager
