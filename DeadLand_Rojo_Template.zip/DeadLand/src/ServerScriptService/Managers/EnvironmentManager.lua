--[[
  EnvironmentManager  [MODULE SCRIPT]
  ==================
  Weather FSM, time-of-day tick, season cycle progression
]]

local EnvironmentManager = {}



return EnvironmentManager
