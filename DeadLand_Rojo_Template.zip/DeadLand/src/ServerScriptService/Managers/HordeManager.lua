--[[
  HordeManager  [MODULE SCRIPT]
  ============
  7-day horde scheduler, wave configs, victory condition tracking
]]

local HordeManager = {}



return HordeManager
