--[[
  VehicleManager  [MODULE SCRIPT]
  ==============
  Vehicle state, ownership, fuel, damage tracking
]]

local VehicleManager = {}



return VehicleManager
