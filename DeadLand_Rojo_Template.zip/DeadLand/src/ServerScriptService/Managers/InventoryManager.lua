--[[
  InventoryManager  [MODULE SCRIPT]
  ================
  Server inventory CRUD with anti-dupe validation
]]

local InventoryManager = {}


--- addItem: Add item to player inventory, handle overflow
function InventoryManager.addItem()
  -- TODO: implement
end

--- removeItem: Remove item by slot or id with quantity
function InventoryManager.removeItem()
  -- TODO: implement
end

--- transferItem: Move item between inventories
function InventoryManager.transferItem()
  -- TODO: implement
end


return InventoryManager
