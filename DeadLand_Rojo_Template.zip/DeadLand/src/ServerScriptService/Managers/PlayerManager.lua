--[[
  PlayerManager  [MODULE SCRIPT]
  =============
  Player join/leave, ProfileStore load, ReplicaService creation
]]

local PlayerManager = {}


--- onPlayerAdded: Load profile, create Replica, spawn character
function PlayerManager.onPlayerAdded()
  -- TODO: implement
end

--- onPlayerRemoving: Save profile, clean up Replica and Maid
function PlayerManager.onPlayerRemoving()
  -- TODO: implement
end


return PlayerManager
