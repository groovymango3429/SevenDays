--[[
  CraftingManager  [MODULE SCRIPT]
  ===============
  Station queues, ingredient deduction, recipe resolution
]]

local CraftingManager = {}



return CraftingManager
