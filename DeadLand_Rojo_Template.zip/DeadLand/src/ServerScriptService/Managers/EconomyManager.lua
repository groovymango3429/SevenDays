--[[
  EconomyManager  [MODULE SCRIPT]
  ==============
  Trader inventory management, buy/sell ledger, dukes balance
]]

local EconomyManager = {}



return EconomyManager
