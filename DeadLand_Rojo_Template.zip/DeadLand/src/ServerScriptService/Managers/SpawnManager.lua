--[[
  SpawnManager  [MODULE SCRIPT]
  ============
  Ambient spawn scheduler, respawn timers, wandering hordes
]]

local SpawnManager = {}


--- trySpawnAmbient: Check heat + proximity then decide to spawn zombie
function SpawnManager.trySpawnAmbient()
  -- TODO: implement
end


return SpawnManager
