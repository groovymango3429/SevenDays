--[[
  PersistenceManager  [MODULE SCRIPT]
  ==================
  Coordinate ProfileStore + chunk saves, auto-save loop
]]

local PersistenceManager = {}



return PersistenceManager
