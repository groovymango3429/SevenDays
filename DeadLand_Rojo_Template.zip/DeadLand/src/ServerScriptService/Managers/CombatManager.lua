--[[
  CombatManager  [MODULE SCRIPT]
  =============
  Damage pipeline entry point, hit validation orchestration
]]

local CombatManager = {}



return CombatManager
