--[[
  AntiCheatManager  [MODULE SCRIPT]
  ================
  Speed, teleport, and damage anomaly detection + kick logic
]]

local AntiCheatManager = {}



return AntiCheatManager
