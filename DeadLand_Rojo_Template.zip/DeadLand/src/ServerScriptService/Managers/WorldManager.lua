--[[
  WorldManager  [MODULE SCRIPT]
  ============
  World init, chunk service boot, first-run POI placement
]]

local WorldManager = {}



return WorldManager
