--[[
  FarmingManager  [MODULE SCRIPT]
  ==============
  Crop growth ticks, harvest processing, soil moisture tracking
]]

local FarmingManager = {}



return FarmingManager
