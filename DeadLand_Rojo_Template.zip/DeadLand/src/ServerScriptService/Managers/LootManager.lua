--[[
  LootManager  [MODULE SCRIPT]
  ===========
  Container loot rolls, respawn timers, GameStage-scaled loot
]]

local LootManager = {}



return LootManager
