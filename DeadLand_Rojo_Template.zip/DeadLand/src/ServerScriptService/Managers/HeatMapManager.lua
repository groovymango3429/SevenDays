--[[
  HeatMapManager  [MODULE SCRIPT]
  ==============
  Per-chunk heat score from noise/fire/light/shots
]]

local HeatMapManager = {}


--- addHeat: Increase heat at grid coordinate by amount
function HeatMapManager.addHeat()
  -- TODO: implement
end

--- getHeat: Query heat score at grid coordinate
function HeatMapManager.getHeat()
  -- TODO: implement
end

--- decayAll: Reduce all scores by decay rate each tick
function HeatMapManager.decayAll()
  -- TODO: implement
end


return HeatMapManager
