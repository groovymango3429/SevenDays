--[[
  QuestManager  [MODULE SCRIPT]
  ============
  Quest state machine, objective tracking, reward granting
]]

local QuestManager = {}


--- acceptQuest: Begin a quest for a player
function QuestManager.acceptQuest()
  -- TODO: implement
end

--- updateObjective: Increment a quest objective counter
function QuestManager.updateObjective()
  -- TODO: implement
end

--- completeQuest: Validate completion, grant rewards
function QuestManager.completeQuest()
  -- TODO: implement
end


return QuestManager
