--[[
  SpawnZombie  [MODULE SCRIPT]
  ===========
  [CMD] spawn zombie <type> <count> [position]
]]

local SpawnZombie = {}



return SpawnZombie
