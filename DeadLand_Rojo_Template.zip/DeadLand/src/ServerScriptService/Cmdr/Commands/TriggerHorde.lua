--[[
  TriggerHorde  [MODULE SCRIPT]
  ============
  [CMD] horde trigger [wave]
]]

local TriggerHorde = {}



return TriggerHorde
