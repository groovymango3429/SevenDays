--[[
  SetSkillLevel  [MODULE SCRIPT]
  =============
  [CMD] skill set <player> <skill> <level>
]]

local SetSkillLevel = {}



return SetSkillLevel
