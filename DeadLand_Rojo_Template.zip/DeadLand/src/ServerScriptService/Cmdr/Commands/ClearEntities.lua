--[[
  ClearEntities  [MODULE SCRIPT]
  =============
  [CMD] entities clear [radius]
]]

local ClearEntities = {}



return ClearEntities
