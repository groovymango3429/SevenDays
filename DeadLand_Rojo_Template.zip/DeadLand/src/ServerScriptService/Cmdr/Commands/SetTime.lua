--[[
  SetTime  [MODULE SCRIPT]
  =======
  [CMD] time set <hour>
]]

local SetTime = {}



return SetTime
