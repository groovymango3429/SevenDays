--[[
  SetWeather  [MODULE SCRIPT]
  ==========
  [CMD] weather <type> <duration>
]]

local SetWeather = {}



return SetWeather
