--[[
  TeleportPlayer  [MODULE SCRIPT]
  ==============
  [CMD] tp <player> <x> <y> <z>
]]

local TeleportPlayer = {}



return TeleportPlayer
