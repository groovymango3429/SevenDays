--[[
  GodMode  [MODULE SCRIPT]
  =======
  [CMD] god <player> on/off
]]

local GodMode = {}



return GodMode
