--[[
  ScreamerAI  [MODULE SCRIPT]
  ==========
  Screamer zombie: patrol, detect player, summon reinforcements
]]

local ScreamerAI = {}



return ScreamerAI
