--[[
  HeatDecayProcessor  [MODULE SCRIPT]
  ==================
  Gradual heat decay per minute — prevents runaway accumulation
]]

local HeatDecayProcessor = {}



return HeatDecayProcessor
