--[[
  HordeWaveConfig  [MODULE SCRIPT]
  ===============
  Wave definitions: zombie types, count ramps, rage escalation
]]

local HordeWaveConfig = {}



return HordeWaveConfig
