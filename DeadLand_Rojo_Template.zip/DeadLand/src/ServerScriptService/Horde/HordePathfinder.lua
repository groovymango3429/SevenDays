--[[
  HordePathfinder  [MODULE SCRIPT]
  ===============
  Blood moon horde navigation toward highest-heat player base
]]

local HordePathfinder = {}



return HordePathfinder
