--[[
  WanderingHordeService  [MODULE SCRIPT]
  =====================
  Mid-day wandering hordes scaled to average player GameStage
]]

local WanderingHordeService = {}



return WanderingHordeService
