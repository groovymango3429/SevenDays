--[[
  HordeScheduler  [MODULE SCRIPT]
  ==============
  7-day cycle timer, blood moon trigger, wave sequencing
]]

local HordeScheduler = {}



return HordeScheduler
