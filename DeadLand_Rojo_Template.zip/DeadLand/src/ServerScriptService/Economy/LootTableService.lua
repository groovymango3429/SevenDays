--[[
  LootTableService  [MODULE SCRIPT]
  ================
  GameStage-scaled loot roll service
]]

local LootTableService = {}



return LootTableService
