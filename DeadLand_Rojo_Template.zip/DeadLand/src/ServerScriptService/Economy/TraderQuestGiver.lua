--[[
  TraderQuestGiver  [MODULE SCRIPT]
  ================
  Generate daily fetch/kill quests per trader NPC
]]

local TraderQuestGiver = {}



return TraderQuestGiver
