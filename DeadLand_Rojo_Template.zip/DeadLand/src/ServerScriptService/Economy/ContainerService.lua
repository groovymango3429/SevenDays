--[[
  ContainerService  [MODULE SCRIPT]
  ================
  Track opened containers, manage respawn schedule
]]

local ContainerService = {}



return ContainerService
