--[[
  TraderService  [MODULE SCRIPT]
  =============
  NPC trader inventory, refresh schedule, safe zone protection
]]

local TraderService = {}



return TraderService
