--[[
  SuphiDatastoreBridge  [MODULE SCRIPT]
  ====================
  Fallback bridge to SuphiDatastore if ProfileStore fails
]]

local SuphiDatastoreBridge = {}



return SuphiDatastoreBridge
