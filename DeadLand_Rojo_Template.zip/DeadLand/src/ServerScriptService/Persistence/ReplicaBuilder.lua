--[[
  ReplicaBuilder  [MODULE SCRIPT]
  ==============
  Build ReplicaService replica containers from loaded profile data
]]

local ReplicaBuilder = {}



return ReplicaBuilder
