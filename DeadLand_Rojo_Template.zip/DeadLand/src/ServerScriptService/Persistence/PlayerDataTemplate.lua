--[[
  PlayerDataTemplate  [MODULE SCRIPT]
  ==================
  Default data structure used when creating a new character profile
]]

local PlayerDataTemplate = {}



return PlayerDataTemplate
