--[[
  DataService  [MODULE SCRIPT]
  ===========
  ProfileStore wrapper: load, save, migration, session lock, retry
]]

local DataService = {}


--- loadProfile: Get or create ProfileStore profile for player
function DataService.loadProfile()
  -- TODO: implement
end

--- saveProfile: Force-save profile to DataStore
function DataService.saveProfile()
  -- TODO: implement
end

--- migrateData: Run version migration on outdated schemas
function DataService.migrateData()
  -- TODO: implement
end


return DataService
