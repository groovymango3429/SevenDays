--[[
  BackupService  [MODULE SCRIPT]
  =============
  Versioned save slot backups using ordered DataStore
]]

local BackupService = {}



return BackupService
