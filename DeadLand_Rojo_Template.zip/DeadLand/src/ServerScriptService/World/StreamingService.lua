--[[
  StreamingService  [MODULE SCRIPT]
  ================
  Per-player chunk subscription sorted by distance priority
]]

local StreamingService = {}



return StreamingService
