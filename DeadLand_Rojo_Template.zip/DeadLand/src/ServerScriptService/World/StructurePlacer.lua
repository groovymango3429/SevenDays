--[[
  StructurePlacer  [MODULE SCRIPT]
  ===============
  POI/building stamping with rotation variants and foundation levelling
]]

local StructurePlacer = {}



return StructurePlacer
