--[[
  RoadGenerator  [MODULE SCRIPT]
  =============
  A*-based road network connecting POIs across the world
]]

local RoadGenerator = {}



return RoadGenerator
