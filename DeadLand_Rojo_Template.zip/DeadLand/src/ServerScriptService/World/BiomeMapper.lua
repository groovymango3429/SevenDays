--[[
  BiomeMapper  [MODULE SCRIPT]
  ===========
  2D noise → biome ID lookup per world column
]]

local BiomeMapper = {}



return BiomeMapper
