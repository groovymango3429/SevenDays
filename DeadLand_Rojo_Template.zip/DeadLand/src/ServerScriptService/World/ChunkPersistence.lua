--[[
  ChunkPersistence  [MODULE SCRIPT]
  ================
  Encode/decode modified chunks to/from DataStore
]]

local ChunkPersistence = {}



return ChunkPersistence
