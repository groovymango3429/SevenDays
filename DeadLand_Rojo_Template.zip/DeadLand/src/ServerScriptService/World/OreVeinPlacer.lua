--[[
  OreVeinPlacer  [MODULE SCRIPT]
  =============
  Ore cluster generation per biome and depth range
]]

local OreVeinPlacer = {}



return OreVeinPlacer
