--[[
  ChunkService  [MODULE SCRIPT]
  ============
  Load/unload chunks per player, LRU cache, dirty flag tracking
]]

local ChunkService = {}


--- requestChunk: Generate or load chunk from DataStore for player
function ChunkService.requestChunk()
  -- TODO: implement
end

--- unloadChunk: Remove chunk from active set when no players need it
function ChunkService.unloadChunk()
  -- TODO: implement
end


return ChunkService
