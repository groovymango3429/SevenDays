--[[
  BlockPhysicsQueue  [MODULE SCRIPT]
  =================
  Queued collapse jobs spread over multiple frames to prevent spikes
]]

local BlockPhysicsQueue = {}



return BlockPhysicsQueue
