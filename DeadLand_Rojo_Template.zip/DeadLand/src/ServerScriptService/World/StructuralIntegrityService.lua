--[[
  StructuralIntegrityService  [MODULE SCRIPT]
  ==========================
  BFS SI propagation on every block place/break event
]]

local StructuralIntegrityService = {}


--- onBlockChanged: Entry point — recalculates SI for affected region
function StructuralIntegrityService.onBlockChanged()
  -- TODO: implement
end


return StructuralIntegrityService
